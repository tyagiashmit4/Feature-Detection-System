/*
 * Sample.cpp
 *
 *  Created on: 11.06.2013
 *      Author: poschmann
 */

#include "condensation/Sample.hpp"

namespace condensation {

double Sample::aspectRatio = 1;
int Sample::nextClusterId = 0;

} /* namespace condensation */
