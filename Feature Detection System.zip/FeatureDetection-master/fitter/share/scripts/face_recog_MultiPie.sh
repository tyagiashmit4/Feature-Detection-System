#!/bin/bash

FD_BUILD_DIR = 

MULTIPIE_ROOT_DIR = Z:\datasets\still01\multiPIE\data\session01\multiview\


