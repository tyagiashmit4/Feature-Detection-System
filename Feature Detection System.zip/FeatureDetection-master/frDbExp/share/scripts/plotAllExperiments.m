clear;
close all;

% Arguments: filename, curveColor, plotWithFtes, plotIndividualDataPoints
% plotCurves('C:\Users\Patrik\Documents\GitHub\experiments\MultiPIE\02_27062014_TexExtr_visCheck\scores\render_frontal_p15_30_45_60.txt', 'r', 0, 0);
% plotCurves('C:\Users\Patrik\Documents\GitHub\experiments\MultiPIE\02_27062014_TexExtr_visCheck\scores\render_frontal_p15.txt', 'g', 0, 0);
plotCurves('C:\Users\Patrik\Documents\GitHub\experiments\MultiPIE\02_27062014_TexExtr_visCheck\scores\render_frontal_p30.txt', 'r', 0, 0);
%plotCurves('C:\Users\Patrik\Documents\GitHub\experiments\MultiPIE\02_27062014_TexExtr_visCheck\scores\render_frontal_p45.txt', 'm', 0, 0);
%plotCurves('C:\Users\Patrik\Documents\GitHub\experiments\MultiPIE\02_27062014_TexExtr_visCheck\scores\render_frontal_p60.txt', 'm', 0, 0);

% plotCurves('C:\Users\Patrik\Documents\GitHub\experiments\MultiPIE\00_00002013_FaceVACS_8_7_0_Baseline\scores\p15_30_45_60.txt', 'g', 0, 0);
% plotCurves('C:\Users\Patrik\Documents\GitHub\experiments\MultiPIE\00_00002013_FaceVACS_8_7_0_Baseline\scores\pm15_30_45_60.txt', 'b', 0, 0);
% plotCurves('C:\Users\Patrik\Documents\GitHub\experiments\MultiPIE\00_00002013_FaceVACS_8_7_0_Baseline\scores\p15.txt', 'g', 0, 0);
plotCurves('C:\Users\Patrik\Documents\GitHub\experiments\MultiPIE\00_00002013_FaceVACS_8_7_0_Baseline\scores\p30.txt', 'b', 0, 0);
%plotCurves('C:\Users\Patrik\Documents\GitHub\experiments\MultiPIE\00_00002013_FaceVACS_8_7_0_Baseline\scores\p45.txt', 'g', 0, 0);
%plotCurves('C:\Users\Patrik\Documents\GitHub\experiments\MultiPIE\00_00002013_FaceVACS_8_7_0_Baseline\scores\p60.txt', 'm', 0, 0);


% Todo:
% -- the numbers: 1) ident. rate 2) ver. rate at x% far (o�)
% -- bei 15�, die DET kurve bzw die vektoren sollten doch egtl 0 elemente
% enthalten, nur ein punkt bei 0, 0 ?
% -- plotCurves: maybe add parameter verifRateAtFAR?
