FeatureDetection
================

A library (and demo applications) for face- and facial feature detection and real-time tracking in 2d-images